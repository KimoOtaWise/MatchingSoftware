<?php
session_start();

// ログイン状態のチェック
if (!isset($_SESSION["USERID"])) {
  header("Location: logout.php");
  exit;
}

?>
<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>成約待っちんぐ</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
		成約待っちんぐ<br/>
		<br/>
		<p>ようこそ<?php echo $_SESSION['USERID'] ?>さん</p>
		<br/>
		<a href = "./matchingMain.php">人材からマッチング</a><br/>
                <br>
                <br>
                <a href="./logout.php">ログアウト</a>
                <br>
	</body>
</html>
