<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>マッチング情報</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
    <?php
      include "./header.php";
    ?>
		<form method="post" action="kensaku.php">
		○メールアドレス
		<input name ="code" type  ="text" style="width:100px"><br/>
		<br/>
		○職種
		<td><select name="example7" size="5"> 
		<option value="val1">業務アプリ</option>
		<option value="val2">WEBアプリ</option>
		<option value="val3">組込・制御</option>
		<option value="val4">ネットワーク</option>
		<option value="val5">インフラ</option>
		</select></td>
		<br>
		<br/>
		○担当フェーズ
		<br>
        <td><input type="checkbox" name="example5" value="val1" />コンサル　<input type="checkbox" name="example5" value="val2" />要件定義　<input type="checkbox" name="example5" value="val3" />基本設計　</td>
        <br>
        <td><input type="checkbox" name="example5" value="val1" />詳細設計　<input type="checkbox" name="example5" value="val2" />製造　<input type="checkbox" name="example5" value="val3" />テスト　</td>
        <br>
        <td><input type="checkbox" name="example5" value="val1" />検証　<input type="checkbox" name="example5" value="val2" />保守・運用　<input type="checkbox" name="example5" value="val3" />導入　</td>
        <br>
        <td><input type="checkbox" name="example5" value="val1" />マネジメント
        <br>
        <br>
		○言語
		<br>
		<td><input type="checkbox" name="example5" value="val1" />java　<input type="checkbox" name="example5" value="val2" />C　<input type="checkbox" name="example5" value="val3" />C#　<input type="checkbox" name="example5" value="val3" />SQL　</td>		
		<br>
		<br>
		○年収
		<br>
		<input name ="code" type  ="text" style="width:100px"><br/>
		<br>
        <br>
		○入社希望日
		<br>
		<input name ="code" type  ="text" style="width:100px"><br/>
		<br>
		<br>
		○応募状況
		<br>
		<td><input type="checkbox" name="example5" value="val1" checked="checked" />未　<input type="checkbox" name="example5" value="val2" />済　
		<br>
		<br>
		<input type="submit"value="検索">
		</form>
		<br/>
                <br>
                <hr>
                <table border=1>
                <tr><th>社名</th><th>職種</th><th>担当業務</th><th>言語</th><th>年収</th><th>入社希望日</th><th>応募状況</th>
                </table>
                <br>
                <br>
	<a href="./menu.php">トップページに戻る</a>
	</body>
	<?php
      include "./footer.php";
    ?>
</html>
