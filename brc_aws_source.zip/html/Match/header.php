<header>
<Div Align="center"><!-- 要素を中央に揃える -->
<h1>成約待っちんぐ</h1>
<HR>
</div>
</header>
