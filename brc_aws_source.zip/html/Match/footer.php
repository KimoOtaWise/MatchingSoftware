<footer>
<Div Align="center"><!-- 要素を中央に揃える -->
<HR>
Copyright© 2015 Brycen All Rights Reserved.
</div>
</footer>
