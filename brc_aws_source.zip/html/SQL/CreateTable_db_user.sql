CREATE TABLE `db_user` (
 `id` int(11) NOT NULL DEFAULT '0',
 `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
 `password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
 PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


insert into db_user values(1,'testUser','$2y$10$d9TSGqpuZL.1Y99VUAZ23eOMJuFFR8shQb4945rxG4tnFG5otkIS6');
