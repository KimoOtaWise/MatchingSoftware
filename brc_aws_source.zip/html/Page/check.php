<!--
作成者:若林
作成日:20150203


<備考>
元ファイル:hina.html
           いきなりはじめるPHP p40,p56参考
           
入力したデータを受け取るには:入力欄のプロパティの入力項目の名前と受け取り先の名前が一致していなければならない。
                             例→ 入力欄 入力項目の名前(index.html):nickname 
                                  受け取り先(check.php):nickname
-->

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>アンケート内容確認</title>
	</head>
	<body>
	
	<?php
	
		
		$nickname=$_POST['nickname'];				//ニックネーム(nickname)を受け取り、変数に格納
		$email=$_POST['email'];					//メールアドレス(email)を受け取り、変数に格納
		$goiken=$_POST['goiken'];					//ご意見(goiken)を受け取り、変数に格納
		
		
		/* ニックネームの処理*/
		
		//入力チェック(入力欄が空な場合)
		if($nickname=='')
		{
			print 'ニックネームが入力されていません<br/>';
		}
		else
		{
			print'ようこそ'; 						//画面にようこそと表示
			print $nickname;						//変数nicknameに格納された値を画面表示
			print '様';
			print '<br/>';
		}
		
		
		/* メールアドレスの処理*/
		
		//入力チェック(入力欄が空な場合)
		if($email=='')
		{
			print 'メールアドレスが入力されていません<br/>';
		}
		else
		{
			print'メールアドレス:'; 						
			print $email;						
			print '<br/>';
		}
		
		
		/* ご意見の処理*/
		
		//入力チェック(入力欄が空な場合)
		if($goiken=='')
		{
			print 'ご意見が入力されていません<br/>';
		}
		else
		{
			print'ご意見『'; 						
			print $goiken;						
			print '』<br/>';
		}
		
		
		/* thanksページの処理*/
		
		//入力チェック(入力欄がどれか一つでも空だったら、thanks.phpに飛べないようにする)
		if($nickname==''||$email==''||$goiken=='')
		{
			print '<form>';
			
			//ボタンを押すとindex.htmlに戻る
			print '<input type="button" onclick="history.back()" value="戻る">';
			
			print '</form>';
		}
		else
		{
			print '<form method="post" action="thanks.php">';
		
			//post送信でnicknameとemailとgoikenの値をthanks.phpに送る。
			//その際、値を画面表示させないようにhiddenに設定し、 . をつけて、thanks.phpで引き渡した値と文字列を連結させる
			print '<input name="nickname" type="hidden" value="'.$nickname.'">';
			print '<input name="email" type="hidden" value="'.$email.'">';
			print '<input name="goiken" type="hidden" value="'.$goiken.'">';
		
			//ボタンを押すとindex.htmlに戻る
			print '<input type="button" onclick="history.back()" value="戻る">';	//onclick="history.back()"で入力したデータをそのまま残して、元のページに戻る
		
			//ボタンを押すとpost送信でthanks.phpに飛ぶ
			print '<input type="submit" value="OK">';
		
			print '</form>';
		}
		
		
	?>
	
	
	</body>
</html>
