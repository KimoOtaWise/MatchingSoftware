<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>アンケート検索結果</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
		<?php
			/***************************************************
			 P.143のコードベースにエラーハンドリングを実装
			 もしtryの中の処理の実行中にDBサーバーがダウンしたら
			 catchの中の処理を実行する
			***************************************************/
			try
			{
				//検索画面で入力されたコード番号を受け取る
				$code = $_POST['code'];
				
				//DBに接続
				$dsn      = 'mysql:dbname=phpkiso;host=brs-project.cflld9dcegxp.us-west-2.rds.amazonaws.com';
				$user     = 'awsuser';
				$password = 'admin123daa';
				$dbh      = new PDO($dsn,$user,$password);
				$dbh      -> query('SET NAMES utf8');
				
				//SELECT文で、テーブル「anketo」のテーブルの中身を全て抽出
				$sql  = 'SELECT *
				         FROM   anketo
				         WHERE  code = ?';
				$stmt = $dbh -> prepare($sql);
				
				//SELECT文の「?」に格納したい値を指定する
				$data[] = $code;
				//$dataの値を「?」に格納して、SQL文を実行する
				$stmt   -> execute($data);
				
				
				
				/*************************************************
				 一行ずつデータを出力する
				 繰り返し条件に1(= TRUE)は無限ループを意味する
				*************************************************/   		   
				
				while(1)
				{
					//$stmtに格納されたデータから、一行を取り出す。
					$rec = $stmt -> fetch(PDO::FETCH_ASSOC);
					
					//レコードが取得できなくなったらこの処理を終了する。
					if($rec == false)
					{
						break;
					}
					
					//フェッチしたデータを出力する。
					print $rec['code'];
					print $rec['nickname'];
					print $rec['email'];
					print $rec['goiken'];
					print '<br/>';
				}
				
				//DB接続を切断
				$dbh = null;
			}
			catch(Exception $e)
			{	
				/*******************************************
				システム障害が発生した場合のメッセージ表示
				*******************************************/
				print '申し訳ございません。</br>';
				print 'システム障害により大変ご迷惑をお掛けしております。';
			}	
		?>
		
		<br/>
		<a href="./menu.php">トップページに戻る</a>
	</body>
</html>
