<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>アンケート一覧</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
		<?php
			/**************************************
			 テーブル「anketo」のデータを全て抽出し
			 抽出結果を出力する
			**************************************/
			
			//DBに接続
			$dsn      = 'mysql:dbname=phpkiso;host=brs-project.cflld9dcegxp.us-west-2.rds.amazonaws.com';
			$user     = 'awsuser';
			$password = 'admin123daa';
			$dbh      = new PDO($dsn,$user,$password);
			$dbh      -> query('SET NAMES utf8');
			
			
			$sql = 'SELECT *
			        FROM   anketo
			        WHERE  1';
			$stmt = $dbh ->prepare($sql);
			$stmt -> execute();
			
			
			/*************************************************
			 一行ずつデータを出力する
			 繰り返し条件に1(= TRUE)は無限ループを意味する
			*************************************************/   
			while(1)
			{
				//$stmtに格納されたデータから、一行を取り出す。
				$rec = $stmt -> fetch(PDO::FETCH_ASSOC);
				
				//レコードが取得できなくなったらこの処理を終了する。
				if($rec == false)
				{
					break;
				}
				
				//フェッチしたデータを出力する。
				print $rec['code'];
				print $rec['nickname'];
				print $rec['email'];
				print $rec['goiken'];
				print '<br/>';
			}
			
			//DB接続を切断
			$dbh = null;
		?>
	<br/>
	<a href="./menu.php">トップページに戻る</a>
	</body>
</html>
