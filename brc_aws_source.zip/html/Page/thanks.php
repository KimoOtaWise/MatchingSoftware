<!--
作成者:若林
作成日:20150203


<備考>
元ファイル:hina.html
           いきなりはじめるPHP p40,p56参考
           
入力したデータを受け取るには:入力欄のプロパティの入力項目の名前と受け取り先の名前が一致していなければならない。
                             例→ 入力欄 入力項目の名前(index.html):nickname 
                                  受け取り先(check.php):nickname
-->

<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>アンケートへのお礼</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
		<?php
			/****************************************
			 P.93のコードをベースにDBを連携させる。
			 サンクスメッセージを表示すると同時に
			 アンケートの回答結果をDBテーブルに格納
			*****************************************/
			
			//接続命令を追加
			$dsn      = 'mysql:dbname=phpkiso;host=brs-project.cflld9dcegxp.us-west-2.rds.amazonaws.com';
			$user     = 'awsuser';
			$password = 'admin123daa';
			$dbh      = new PDO($dsn,$user,$password);
			$dbh      -> query('SET NAMES utf8');

			$nickname = $_POST['nickname'];
			$email    = $_POST['email'];
			$goiken   = $_POST['goiken'];
			
			//サニタイジング
			$nickname = htmlspecialchars($nickname);
			$email    = htmlspecialchars($email);
			$goiken   = htmlspecialchars($goiken);
			
			
			print $nickname;
			print '様<br/>';
			print 'ご意見ありがとうございました。<br/>';
			print '頂いたご意見『';
			print $goiken;
			print '』<br/>';
			print $email;
			print 'にメールを送りましたのでご確認下さい。';
			
			
			//テーブルにレコードを追加
			$sql = 'INSERT INTO anketo
			        ( nickname
			         ,email
			         ,goiken
			        )VALUES(
			          "'.$nickname.'"
			         ,"'.$email.'"
			         ,"'.$goiken.'"
			        )';
			$stmt = $dbh ->prepare($sql);
			$stmt -> execute();
			
			//DB接続の切断
			$dbh = null;
		?>
		
		<br/>
		<a href="./menu.php">トップページに戻る</a>
	</body>
</html>
