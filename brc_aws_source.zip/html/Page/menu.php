<?php
session_start();

// ログイン状態のチェック
if (!isset($_SESSION["USERID"])) {
  header("Location: logout.php");
  exit;
}

?>
<!DOCTYPE HTML PUBLIC"-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>アンケート管理システム</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	</head>
	
	<body>
		アンケート管理システム<br/>
		<br/>
		<p>ようこそ<?php echo $_SESSION['USERID'] ?>さん</p>
		<br/>
		<a href = "./ichiran.php">アンケート一覧</a><br/>
		<br/>
		<br/>
		<a href = "./kensaku.html">アンケート検索</a><br/>
		<br/>
		<br/>
		<a href = "./anketo.html">アンケート送信</a><br/>
                <br>
                <br>
                <a href="./logout.php">ログアウト</a>
                <br>
	</body>
</html>
